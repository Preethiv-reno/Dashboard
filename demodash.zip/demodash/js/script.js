	var Myapp = angular.module('Myapp',[]);
	
	Myapp.controller('Productcntrl',function($scope){
	$scope.section = false;
	$scope.newsection = false;
	$scope.main_content = true;
	$scope.form_content = false;
	$scope.userList = [
		{id:"us1",name:"Preethiv",email:"dfd@ddfd.fff",mobile:9659411309,jobdes:"UI Developer",img:'user_1.jpg'},
		{id:"us2",name:"Renold",email:"bvb@fdf.fdf",mobile:6767845654,jobdes:"UX Developer",img:'user_2.jpg'},
		{id:"us3",name:"Shri",email:"bfgfbf@ghg.hjhk",mobile:5568986656,jobdes:"JAVA Developer",img:'user_3.jpg'},
		{id:"us4",name:"Sadam",email:"ghgdd@hjh.hjh",mobile:7634332343,jobdes:"HR",img:'user_1.jpg'},
	];
	
    $scope.edit = function(id){
		var index = selectedIndex(id);
		var User = $scope.userList[index];
		$scope.name = User.name;
		$scope.email_ID = User.email;
		$scope.mob_Num = User.mobile;
		$scope.job_Desc = User.jobdes;
		$scope.id = User.id;
		$scope.form_content = true;
		$scope.section = true;
		$scope.newsection = false;
		$scope.main_content = false;
	};
	
	$scope.save = function(){
		var index = selectedIndex($scope.id);
		$scope.userList[index].name = $scope.name;
		$scope.userList[index].email = $scope.email_ID;
		$scope.userList[index].mobile = $scope.mob_Num;
		$scope.userList[index].jobdes = $scope.job_Desc;
		
		$scope.name = "";
		$scope.email_ID = "";
		$scope.mob_Num = "";
		$scope.job_Desc = "";
		$scope.id="";
		
		$scope.form_content = false;
	    $scope.main_content = true;
	};
	
	$scope.add = function(){
		var userTotal = $scope.userList.length;
		var newUser = Number(userTotal + 1);
		var userId = 'us'+newUser;
		var userImg = 'newuser.png';
		$scope.userList.push(
			{id:userId,name:$scope.name,email:$scope.email_ID,mobile:$scope.mob_Num,jobdes:$scope.job_Desc,img:userImg},
		);
		$scope.name = "";
		$scope.email_ID = "";
		$scope.mob_Num = "";
		$scope.job_Desc = "";
		$scope.id="";
		
		$scope.form_content = false;
	    $scope.main_content = true;
	};
	
	$scope.newuser = function(){
		$scope.newsection = true;
		$scope.form_content = true;
	    $scope.main_content = false;
		$scope.section = false;
		
		$scope.name = "";
		$scope.email_ID = "";
		$scope.mob_Num = "";
		$scope.job_Desc = "";
		$scope.id="";
	}
	
	$scope.cancel = function(){
		$scope.form_content = false;
	    $scope.main_content = true;
	}
	
	
	
	function selectedIndex(id){
	
		for(i=0;i<=$scope.userList.length;i++)
		{
			if($scope.userList[i].id == id)
			{
				return i;
			}
		}
	
	}
	});