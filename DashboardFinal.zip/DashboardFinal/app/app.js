
var dashboardApp = angular.module('dashboardApp',['ngRoute','dashboardApp.userFactory']);


	   dashboardApp.config(['$routeProvider',function($routeProvider){
				$routeProvider
				.when('/view1', {
			templateUrl: 'view/dashboard.html',
			controller: 'dashboardcontroller'
		})
		.otherwise({
			redirectTo: '/view1'
		});
				  //  .otherwise({templateUrl:"view/dashboard.html"});
			}]);
	dashboardApp.controller('dashboardcontroller',function($scope,userAPIfactory){
	$scope.section = false;
	$scope.newsection = false;
	$scope.main_content = true;
	$scope.form_content = false;
	$scope.del_User = false;
	
	var t1 = new TimelineLite();
	var t2 = new TimelineLite();
	
	userAPIfactory.getuserlist().success(function(response){
			  $scope.userList = userAPIfactory.saveuserlist(response);
		});
	
	$scope.deluser = function(id){
		var index = selectedIndex($scope.id);
		$scope.userList.splice(index,1);
		$scope.form_content = false;
	    $scope.main_content = true;
		$scope.del_User = false;
		t1.restart();
	}

    $scope.edit = function(id){
		var index = selectedIndex(id);
		var User = $scope.userList[index];
		$scope.name = User.name;
		$scope.email_ID = User.email;
		$scope.mob_Num = User.mobile;
		$scope.job_Desc = User.jobdes;
		$scope.id = User.id;
		$scope.form_content = true;
		$scope.section = true;
		$scope.newsection = false;
		$scope.main_content = false;
		$scope.del_User = true;
		t2.restart();
	};
	
	$scope.save = function(){
		var index = selectedIndex($scope.id);
		$scope.userList[index].name = $scope.name;
		$scope.userList[index].email = $scope.email_ID;
		$scope.userList[index].mobile = $scope.mob_Num;
		$scope.userList[index].jobdes = $scope.job_Desc;
		
		$scope.name = "";
		$scope.email_ID = "";
		$scope.mob_Num = "";
		$scope.job_Desc = "";
		$scope.id="";
		
		$scope.form_content = false;
	    $scope.main_content = true;
		t1.restart();
	};
	
	$scope.add = function(){
		var userTotal = $scope.userList.length;
		var newUser = Number(userTotal + 1);
		var userId = 'us'+newUser;
		var userImg = 'newuser.png';
		$scope.userList.push(
			{id:userId,name:$scope.name,email:$scope.email_ID,mobile:$scope.mob_Num,jobdes:$scope.job_Desc,img:userImg},
		);
		$scope.name = "";
		$scope.email_ID = "";
		$scope.mob_Num = "";
		$scope.job_Desc = "";
		$scope.id="";
		
		$scope.form_content = false;
	    $scope.main_content = true;
		
	};
	
	$scope.newuser = function(){
		$scope.newsection = true;
		$scope.form_content = true;
	    $scope.main_content = false;
		$scope.section = false;
		
		$scope.name = "";
		$scope.email_ID = "";
		$scope.mob_Num = "";
		$scope.job_Desc = "";
		$scope.id="";
		t2.restart();
	}
	
	$scope.cancel = function(){
		$scope.form_content = false;
	    $scope.main_content = true;
		$scope.del_User = false;
		$scope.name = "";
		$scope.email_ID = "";
		$scope.mob_Num = "";
		$scope.job_Desc = "";
		$scope.id="";
		t1.restart();
	}
	
	$scope.list = function(){
		var result = document.getElementsByClassName("user_Card");
		var wrappedQueryResult = angular.element(result);
		wrappedQueryResult.addClass('list');
		var icons = document.getElementsByClassName("msg_box");
		var wrappedQueryicons = angular.element(icons);
		wrappedQueryicons.addClass('list');
		var icons1 = document.getElementsByClassName("view_box");
		var wrappedQueryicons1 = angular.element(icons1);
		wrappedQueryicons1.addClass('list');
		var textalig = angular.element(document.querySelector(".user_Container"));
		textalig.css('text-align','center');
		var icocolor = angular.element(document.querySelector(".icgrid"));
		icocolor.css({'color':'#ccc','background':'#fff'});
		var icocolor1 = angular.element(document.querySelector(".iclist"));
		icocolor1.css({'color':'#fff','background':'#587EF5'});
		t1.restart();
	}
	
	$scope.grid = function(){
		var result = document.getElementsByClassName("user_Card");
		var wrappedQueryResult = angular.element(result);
		wrappedQueryResult.removeClass('list');
		var icons = document.getElementsByClassName("msg_box");
		var wrappedQueryicons = angular.element(icons);
		wrappedQueryicons.removeClass('list');
		var icons1 = document.getElementsByClassName("view_box");
		var wrappedQueryicons1 = angular.element(icons1);
		wrappedQueryicons1.removeClass('list');
		var textalig = angular.element(document.querySelector(".user_Container"));
		textalig.css('text-align','left');
		var icocolor = angular.element(document.querySelector(".icgrid"));
		icocolor.css({'color':'#fff','background':'#587EF5'});
		var icocolor1 = angular.element(document.querySelector(".iclist"));
		icocolor1.css({'color':'#ccc','background':'#fff'});
	}
	
	function selectedIndex(id){
	
		for(i=0;i<=$scope.userList.length;i++)
		{
			if($scope.userList[i].id == id)
			{
				return i;
			}
		}
	
	}
	
	
	setTimeout(function(){
		 t1.staggerFrom(angular.element(document.querySelectorAll('.user_Card')), 1.5,{ease: Power4.easeOut, y:-300},0.2);
		 t1.from(angular.element(document.querySelector('.view_type_btn')), 1, {x:-300, ease: Elastic.easeOut.config(1, 0.3)});
		 t1.from(angular.element(document.querySelector('.add_animate')), 0.5, {x:-300, ease: Elastic.easeOut.config(1, 0.3)});
		 t2.from(angular.element(document.querySelector('.form_heading')), 1, {y:-300,ease: Bounce.easeOut});
		 t2.staggerFrom(angular.element(document.querySelectorAll('.field_Wrap')), 1,{ease: Power4.easeOut, y:-300},0.3);
		 t2.from(angular.element(document.querySelectorAll('.btn_Holder')), 0.5,{ opacity:0,ease:Power0.easeIn,y:-50});
	},300);
	
	
	})