angular.module('dashboardApp.userFactory',[])
	.factory('userAPIfactory',function($http){
		
		var userdetail = {}	
		var userlist = ''
		userdetail.getuserlist = function(){
			
			return $http.get('src/userlist.json')
		}
		userdetail.saveuserlist = function(data){ 
		
			userlist = data;
			return userlist;
		}
		
		return userdetail;
	});